/*
  # Fix RLS Security Vulnerabilities

  1. Changes
    - Drop insecure policies that use USING (true)
    - Create secure policies that require authentication
    - Add policy for authenticated users to view submissions
    - Add policy for authenticated users to delete submissions
  
  2. Security
    - Only authenticated users can view submissions
    - Only authenticated users can delete submissions
    - Anonymous users can still insert new submissions (for contact form)
*/

-- Drop the insecure policies
DROP POLICY IF EXISTS "Allow reading all submissions" ON contact_submissions;
DROP POLICY IF EXISTS "Allow deleting submissions" ON contact_submissions;

-- Create secure policy for authenticated users to view submissions
CREATE POLICY "Authenticated users can view submissions"
  ON contact_submissions
  FOR SELECT
  TO authenticated
  USING (true);

-- Create secure policy for authenticated users to delete submissions
CREATE POLICY "Authenticated users can delete submissions"
  ON contact_submissions
  FOR DELETE
  TO authenticated
  USING (true);

-- Keep the existing insert policy for anonymous users (contact form)
-- This should already exist from previous migrations