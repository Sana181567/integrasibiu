/*
  # Fix Contact Submissions RLS Security

  1. Changes
    - Drop the insecure RLS policy that allows unrestricted anonymous inserts
    - Keep the SELECT policy for authenticated admin users only
    
  2. Security Model
    - All contact form submissions must go through the Edge Function
    - The Edge Function uses service role key to bypass RLS
    - This allows proper validation and rate limiting
    - No direct anonymous access to insert data
    
  3. Notes
    - This fixes the security vulnerability where anon users could insert
      unlimited data without validation
    - Contact submissions are now only possible via the secure Edge Function
      at /functions/v1/send-contact-email
*/

DROP POLICY IF EXISTS "Anyone can submit contact form" ON contact_submissions;
