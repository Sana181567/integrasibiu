/*
  # Remove Insecure Anonymous INSERT Policy

  ## 1. Overview
  This migration fixes a critical RLS security vulnerability where the `contact_submissions` 
  table had an INSERT policy with `WITH CHECK (true)`, allowing unrestricted data insertion.

  ## 2. Security Issue
  - **Problem**: Policy "Anyone can submit contact form" allows any anonymous user to insert 
    arbitrary data without validation or restrictions
  - **Risk**: This bypasses row-level security and could lead to spam, data abuse, or injection attacks
  - **CVE Context**: RLS policies with `WITH CHECK (true)` effectively disable security for that operation

  ## 3. Solution
  - **Action**: Remove the anon INSERT policy completely
  - **Impact**: Contact form submissions MUST now go through the Edge Function `send-contact-email`
  - **Security Benefit**: 
    - Edge Function provides server-side validation
    - Service role key allows controlled insertion
    - Can implement rate limiting in the Edge Function
    - Prevents direct database manipulation

  ## 4. How Contact Forms Work After This Change
  1. User fills out contact form on website
  2. Frontend calls Edge Function: `/functions/v1/send-contact-email`
  3. Edge Function validates input data
  4. Edge Function uses service_role key to insert data (bypasses RLS)
  5. Service role operations are logged and auditable

  ## 5. Existing Admin Policies (Unchanged)
  - Admins can SELECT submissions (view in admin panel)
  - Admins can DELETE submissions (remove spam/old entries)
  - These policies remain secure and functional

  ## 6. Verification
  After this migration:
  - Direct INSERT from anon users will FAIL (this is correct behavior)
  - Contact form through Edge Function will SUCCEED
  - Admin operations will continue to work normally
*/

-- Drop the insecure anonymous INSERT policy
-- This policy had WITH CHECK (true) which allowed unrestricted access
DROP POLICY IF EXISTS "Anyone can submit contact form" ON public.contact_submissions;

-- Ensure RLS remains enabled
-- Without any INSERT policy for anon role, anonymous users cannot insert directly
-- This forces all insertions to go through the secure Edge Function
ALTER TABLE public.contact_submissions ENABLE ROW LEVEL SECURITY;

-- The following policies remain in place (defined in previous migrations):
-- 1. "Admins can view all submissions" - SELECT for authenticated admins
-- 2. "Admins can delete submissions" - DELETE for authenticated admins
-- 
-- No INSERT policy for anon = Maximum security
-- Edge Function with service_role bypasses RLS = Controlled insertion with validation