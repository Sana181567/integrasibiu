/*
  # Fix RLS Security and Performance Issues

  1. Changes Made
    - Remove duplicate RLS policies on contact_submissions table
    - Fix auth function calls to use (select auth.function()) for better performance
    - Fix is_admin function to use stable search_path
    - Consolidate to single set of admin policies

  2. Security Improvements
    - Fixed function search_path to prevent SQL injection attacks
    - Optimized RLS policy performance by wrapping auth functions in SELECT
    - Removed duplicate permissive policies that could cause confusion

  3. Design Decisions
    - The INSERT policy for anon role intentionally allows unrestricted access
      This is necessary for the public contact form to work
    - Admin access is controlled through app_metadata.role = 'admin'
    - Using is_admin() function for cleaner, more maintainable policies

  4. Performance Notes
    - Auth functions wrapped in (select ...) are evaluated once per query
    - Without wrapping, they would re-evaluate for each row
    - This significantly improves performance at scale
*/

-- Drop all existing policies on contact_submissions
DROP POLICY IF EXISTS "Admin users can view submissions" ON public.contact_submissions;
DROP POLICY IF EXISTS "Admin users can delete submissions" ON public.contact_submissions;
DROP POLICY IF EXISTS "Only admins can view submissions" ON public.contact_submissions;
DROP POLICY IF EXISTS "Only admins can delete submissions" ON public.contact_submissions;
DROP POLICY IF EXISTS "Anyone can submit contact form" ON public.contact_submissions;

-- Recreate is_admin function with stable search_path
-- This prevents SQL injection and satisfies security requirements
DROP FUNCTION IF EXISTS public.is_admin();

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  RETURN (
    SELECT COALESCE(
      ((select auth.jwt())->>'role' = 'service_role') OR
      ((select auth.jwt())->'app_metadata'->>'role' = 'admin'),
      false
    )
  );
END;
$$;

-- Recreate policies with optimized auth function calls
-- These use (select auth.function()) which is evaluated once per query

-- Allow anonymous users to submit contact forms
-- This is intentional - the contact form is public
CREATE POLICY "Anyone can submit contact form"
  ON public.contact_submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Only admins can view submissions
CREATE POLICY "Admins can view all submissions"
  ON public.contact_submissions
  FOR SELECT
  TO authenticated
  USING (
    ((select auth.jwt())->'app_metadata'->>'role' = 'admin')
  );

-- Only admins can delete submissions
CREATE POLICY "Admins can delete submissions"
  ON public.contact_submissions
  FOR DELETE
  TO authenticated
  USING (
    ((select auth.jwt())->'app_metadata'->>'role' = 'admin')
  );

-- Verify RLS is still enabled
ALTER TABLE public.contact_submissions ENABLE ROW LEVEL SECURITY;