/*
  # Fix RLS Security - Admin Only Access

  ## Summary
  This migration fixes critical RLS security vulnerabilities by restricting access to contact submissions to admin users only.

  ## Changes
  1. **Drop Insecure Policies**
     - Removes "Authenticated users can view submissions" policy (allowed all authenticated users)
     - Removes "Authenticated users can delete submissions" policy (allowed all authenticated users)
  
  2. **Create Admin-Only Policies**
     - "Admin users can view submissions" - Only users with admin role can SELECT submissions
     - "Admin users can delete submissions" - Only users with admin role can DELETE submissions
  
  3. **Keep Anonymous Insert Policy**
     - Anonymous users can still submit contact forms (INSERT remains unchanged)

  ## Security
  - Uses `auth.jwt()` to check for admin role in user's app_metadata
  - Only users with `app_metadata->>'role' = 'admin'` can access submissions
  - Anonymous users retain INSERT capability for contact form functionality
  - All other access is denied by default (RLS enabled)

  ## Notes
  - To grant admin access, set user's app_metadata: `{"role": "admin"}`
  - This can be done via Supabase Dashboard or using service role key
  - Example SQL to grant admin: 
    `UPDATE auth.users SET raw_app_meta_data = '{"role": "admin"}' WHERE email = 'admin@example.com';`
*/

-- Drop the insecure policies that allow all authenticated users
DROP POLICY IF EXISTS "Authenticated users can view submissions" ON contact_submissions;
DROP POLICY IF EXISTS "Authenticated users can delete submissions" ON contact_submissions;

-- Create secure policy for admin users to view submissions
CREATE POLICY "Admin users can view submissions"
  ON contact_submissions
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt()->>'role' = 'admin' OR 
     auth.jwt()->'app_metadata'->>'role' = 'admin')
  );

-- Create secure policy for admin users to delete submissions
CREATE POLICY "Admin users can delete submissions"
  ON contact_submissions
  FOR DELETE
  TO authenticated
  USING (
    (auth.jwt()->>'role' = 'admin' OR 
     auth.jwt()->'app_metadata'->>'role' = 'admin')
  );

-- Verify the INSERT policy for anonymous users still exists
-- This should already exist from previous migrations and allows contact form submissions
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'contact_submissions' 
    AND policyname = 'Anyone can submit contact form'
  ) THEN
    CREATE POLICY "Anyone can submit contact form"
      ON contact_submissions
      FOR INSERT
      TO anon
      WITH CHECK (true);
  END IF;
END $$;