import { Calendar, Clock, BookMarked, Phone } from 'lucide-react';

interface ProgramsProps {
  onNavigate: (page: string) => void;
}

export default function Programs({ onNavigate }: ProgramsProps) {
  return (
    <div>
      <section className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6 font-cormorant">Programe & Programări</h1>
          <p className="text-xl text-white/90 font-lora">
            Flexibilitate și organizare pentru succesul fiecărui elev
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Calendar className="text-[#00A8CC] mx-auto mb-4" size={48} />
            <h2 className="text-4xl font-bold text-black mb-4 font-cormorant">
              Cum funcționează programarea?
            </h2>
            <p className="text-lg text-[#2C3E50]/70 max-w-3xl mx-auto">
              Am creat un proces simplu și flexibil pentru a veni în întâmpinarea nevoilor fiecărei familii
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl text-center border-t-4 border-[#00A8CC]">
              <div className="w-16 h-16 bg-[#00A8CC]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-[#00A8CC]">1</span>
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Contact inițial
              </h3>
              <p className="text-gray-700 font-lora">
                Ne contactați telefonic sau prin formularul de contact pentru a stabili o primă întâlnire de evaluare.
              </p>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl text-center border-t-4 border-[#FFB703]">
              <div className="w-16 h-16 bg-[#FFB703]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-[#FFB703]">2</span>
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Sesiuni de evaluare gratuite
              </h3>
              <p className="text-gray-700 font-lora">
                Identificăm nivelul actual de cunoștințe și zonele care necesită atenție specială.
              </p>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl text-center border-t-4 border-black">
              <div className="w-16 h-16 bg-black/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl font-bold text-black">3</span>
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Program personalizat
              </h3>
              <p className="text-gray-700 font-lora">
                Stabilim împreună un program flexibil și creăm un plan de învățare adaptat nevoilor elevului.
              </p>
            </div>
          </div>

          <div className="bg-yellow-50 p-10 rounded-3xl mb-16 border border-[#FFB703]">
            <div className="text-center mb-8">
              <Clock className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Flexibilitate în programare
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Înțelegem că fiecare familie are un program încărcat. De aceea, oferim opțiuni flexibile de programare.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Zile disponibile
                </h3>
                <ul className="space-y-2 font-lora">
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#00A8CC] rounded-full"></div>
                    <span className="text-gray-700">Luni - Vineri: 08:00 - 21:00</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#00A8CC] rounded-full"></div>
                    <span className="text-gray-700">Sâmbătă: 09:00 - 20:00</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#00A8CC] rounded-full"></div>
                    <span className="text-gray-700">Duminică: Program special (la cerere)</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Durata ședințelor
                </h3>
                <ul className="space-y-2 font-lora">
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                    <span className="text-gray-700">Ședințe de 120 minute (standard)</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                    <span className="text-gray-700">Ședințe de 90 minute (intensiv)</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                    <span className="text-gray-700">Sesiuni maratoane (pregătire examene)</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mb-16">
            <div className="text-center mb-8">
              <BookMarked className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Pachete disponibile
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Oferim diverse opțiuni de pachete pentru a se potrivi diferitelor nevoi și bugete
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-shadow border-2 border-transparent hover:border-[#00A8CC]">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-black mb-2 font-cormorant">
                    Flexibil
                  </h3>
                  <p className="text-sm text-gray-700 font-lora">
                    Perfect pentru încercare
                  </p>
                </div>
                <ul className="space-y-3 mb-8 font-lora">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#5BA3B8] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Ședințe individuale</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#5BA3B8] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Plată per ședință</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#5BA3B8] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Fără obligativitate</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#5BA3B8] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Programare flexibilă</span>
                  </li>
                </ul>
                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full bg-[#5BA3B8] text-white py-3 rounded-full font-semibold hover:bg-[#4A90A4] transition-all"
                >
                  Solicită informații
                </button>
              </div>

              <div className="bg-gradient-to-br from-[#5BA3B8] to-[#7EB09B] p-8 rounded-3xl shadow-2xl text-white transform scale-105">
                <div className="text-center mb-6">
                  <div className="bg-white text-[#5BA3B8] text-xs font-bold px-3 py-1 rounded-full inline-block mb-3">
                    CEL MAI POPULAR
                  </div>
                  <h3 className="text-2xl font-bold mb-2 font-cormorant">
                    Standard
                  </h3>
                  <p className="text-sm text-white/90 font-lora">
                    Ideal pentru progres constant
                  </p>
                </div>
                <ul className="space-y-3 mb-8 font-lora">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-white rounded-full mt-2"></div>
                    <span className="text-white/90">4 ședințe pe lună</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-white rounded-full mt-2"></div>
                    <span className="text-white/90">1 ședință pe săptămână</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-white rounded-full mt-2"></div>
                    <span className="text-white/90">Reducere semnificativă</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-white rounded-full mt-2"></div>
                    <span className="text-white/90">Materiale incluse</span>
                  </li>
                </ul>
                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full bg-white text-[#5BA3B8] py-3 rounded-full font-semibold hover:bg-[#E8DCC4] transition-all"
                >
                  Solicită informații
                </button>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-shadow border-2 border-transparent hover:border-[#7EB09B]">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-[#2C3E50] mb-2 font-cormorant">
                    Intensiv
                  </h3>
                  <p className="text-sm text-[#2C3E50]/70 font-lora">
                    Pentru rezultate rapide
                  </p>
                </div>
                <ul className="space-y-3 mb-8 font-lora">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#7EB09B] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">8+ ședințe pe lună</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#7EB09B] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">2+ ședințe pe săptămână</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#7EB09B] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Program personalizat</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-[#7EB09B] rounded-full mt-2"></div>
                    <span className="text-[#2C3E50]/80">Suport suplimentar</span>
                  </li>
                </ul>
                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full bg-[#7EB09B] text-white py-3 rounded-full font-semibold hover:bg-[#4A90A4] transition-all"
                >
                  Solicită informații
                </button>
              </div>
            </div>
          </div>

          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-black mb-4 font-cormorant">
                Lista Prețuri Meditații
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Abonamentul lunar include 4 ședințe pe lună și oferă o reducere față de plata per ședință
              </p>
            </div>

            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#00A8CC] to-[#0086AC] text-white">
                      <th className="py-4 px-6 text-left font-cormorant text-lg">Disciplină</th>
                      <th className="py-4 px-6 text-left font-cormorant text-lg">Timp/Ședință</th>
                      <th className="py-4 px-6 text-left font-cormorant text-lg">Preț/Ședință</th>
                      <th className="py-4 px-6 text-left font-cormorant text-lg">Abonament Lunar<br/><span className="text-sm font-normal">(4 ședințe/lună)</span></th>
                    </tr>
                  </thead>
                  <tbody className="font-lora">
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Matematică – Nivel primar</td>
                      <td className="py-4 px-6 text-gray-700">90 min (1h și 30 min)</td>
                      <td className="py-4 px-6 text-gray-700">80 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">300 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Matematică – Nivel gimnazial<br/><span className="text-sm text-gray-600">(inclusiv evaluarea națională)</span></td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">100 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">380 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(5% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Matematică – Nivel liceal<br/><span className="text-sm text-gray-600">(inclusiv BAC)</span></td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">120 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">450 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Limba română – Nivel primar</td>
                      <td className="py-4 px-6 text-gray-700">90 min (1h și 30 min)</td>
                      <td className="py-4 px-6 text-gray-700">80 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">300 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Limba română – Nivel gimnazial<br/><span className="text-sm text-gray-600">(inclusiv evaluarea națională)</span></td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">100 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">380 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(5% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Limba română – Nivel liceal<br/><span className="text-sm text-gray-600">(inclusiv BAC)</span></td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">120 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">450 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Biologie – BAC</td>
                      <td className="py-4 px-6 text-gray-700">90 min (1h și 30 min)</td>
                      <td className="py-4 px-6 text-gray-700">100 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">380 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(5% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Biologie – Admitere medicină</td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">150 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">550 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(8% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Limba engleză – Nivel primar</td>
                      <td className="py-4 px-6 text-gray-700">90 min (1h și 30 min)</td>
                      <td className="py-4 px-6 text-gray-700">80 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">300 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Limba engleză – Nivel gimnazial</td>
                      <td className="py-4 px-6 text-gray-700">90 min (1h și 30 min)</td>
                      <td className="py-4 px-6 text-gray-700">80 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">300 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Informatică – Nivel liceal<br/><span className="text-sm text-gray-600">(inclusiv bacalaureat)</span></td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">120 lei</td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-[#00A8CC]">450 lei</span>
                        <span className="ml-2 text-sm text-green-600 font-semibold">(6% discount)</span>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-black">Ateliere educaționale</td>
                      <td className="py-4 px-6 text-gray-700">120 min (2h)</td>
                      <td className="py-4 px-6 text-gray-700">80-150 lei</td>
                      <td className="py-4 px-6 text-gray-500 italic">-</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-8 bg-yellow-50 p-6 rounded-2xl border border-yellow-200">
              <p className="text-gray-700 text-center font-lora">
                <span className="font-bold text-black">Notă:</span> Abonamentul lunar oferă o reducere semnificativă față de plata individuală per ședință și include 4 ședințe garantate pe lună.
              </p>
            </div>
          </div>

          <div className="bg-white p-10 rounded-3xl shadow-xl text-center">
            <Phone className="text-[#4A90A4] mx-auto mb-4" size={48} />
            <h2 className="text-3xl font-bold text-[#2C3E50] mb-4 font-cormorant">
              Gata să începi?
            </h2>
            <p className="text-lg text-[#2C3E50]/70 mb-8 max-w-2xl mx-auto font-lora">
              Contactează-ne astăzi pentru a programa o evaluare gratuită și a discuta despre nevoile tale educaționale.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="bg-[#4A90A4] text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-[#5BA3B8] transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Programează evaluarea gratuită
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
