import { User, Users, BookOpen, GraduationCap, Target, Clock, X } from 'lucide-react';
import { useState } from 'react';

interface SubjectPricing {
  name: string;
  levels: {
    title: string;
    duration: string;
    pricePerSession: string;
    monthlySubscription: string;
    discount: string;
  }[];
}

export default function Tutoring() {
  const [selectedSubject, setSelectedSubject] = useState<SubjectPricing | null>(null);

  const subjectPricing: SubjectPricing[] = [
    {
      name: 'Limba și literatura română',
      levels: [
        {
          title: 'Nivel primar',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        },
        {
          title: 'Nivel gimnazial (inclusiv evaluarea națională)',
          duration: '120 min (2h)',
          pricePerSession: '100 lei',
          monthlySubscription: '380 lei',
          discount: '5%'
        },
        {
          title: 'Nivel liceal (inclusiv BAC)',
          duration: '120 min (2h)',
          pricePerSession: '120 lei',
          monthlySubscription: '450 lei',
          discount: '6%'
        }
      ]
    },
    {
      name: 'Limba Engleză',
      levels: [
        {
          title: 'Nivel primar',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        },
        {
          title: 'Nivel gimnazial',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        }
      ]
    },
    {
      name: 'Limba Germană',
      levels: [
        {
          title: 'Nivel primar',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        },
        {
          title: 'Nivel gimnazial',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        }
      ]
    },
    {
      name: 'Matematică',
      levels: [
        {
          title: 'Nivel primar',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '80 lei',
          monthlySubscription: '300 lei',
          discount: '6%'
        },
        {
          title: 'Nivel gimnazial (inclusiv evaluarea națională)',
          duration: '120 min (2h)',
          pricePerSession: '100 lei',
          monthlySubscription: '380 lei',
          discount: '5%'
        },
        {
          title: 'Nivel liceal (inclusiv BAC)',
          duration: '120 min (2h)',
          pricePerSession: '120 lei',
          monthlySubscription: '450 lei',
          discount: '6%'
        }
      ]
    },
    {
      name: 'Biologie BAC',
      levels: [
        {
          title: 'Bacalaureat',
          duration: '90 min (1h și 30 min)',
          pricePerSession: '100 lei',
          monthlySubscription: '380 lei',
          discount: '5%'
        }
      ]
    },
    {
      name: 'Biologie admitere Medicină',
      levels: [
        {
          title: 'Admitere medicină',
          duration: '120 min (2h)',
          pricePerSession: '150 lei',
          monthlySubscription: '550 lei',
          discount: '8%'
        }
      ]
    },
    {
      name: 'Informatică',
      levels: [
        {
          title: 'Nivel liceal (inclusiv bacalaureat)',
          duration: '120 min (2h)',
          pricePerSession: '120 lei',
          monthlySubscription: '450 lei',
          discount: '6%'
        }
      ]
    },
    {
      name: 'Informatică admitere facultate',
      levels: [
        {
          title: 'Admitere facultate',
          duration: '120 min (2h)',
          pricePerSession: '120 lei',
          monthlySubscription: '450 lei',
          discount: '6%'
        }
      ]
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6 font-cormorant">Meditații personalizate</h1>
          <p className="text-xl text-white/90 font-lora">
            Oferim programe educaționale complete, adaptate nevoilor fiecărui elev
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4 font-cormorant">
              Tipuri de meditații
            </h2>
            <p className="text-lg text-gray-700 font-lora">
              Alege varianta care se potrivește cel mai bine stilului de învățare al elevului
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-shadow border-l-4 border-[#00A8CC]">
              <div className="w-16 h-16 bg-[#00A8CC]/10 rounded-full flex items-center justify-center mb-6">
                <User className="text-[#00A8CC]" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-black mb-4 font-cormorant">
                Meditații individuale
              </h3>
              <p className="text-gray-700 mb-6 font-lora">
                Atenție exclusivă și program complet personalizat. Ideale pentru elevi care au nevoie de sprijin intensiv sau care doresc să avanseze rapid.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#00A8CC] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">100% atenție din partea profesorului</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#00A8CC] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Ritm de învățare adaptat</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#00A8CC] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Program flexibil</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#00A8CC] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Focus pe punctele slabe</span>
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-shadow border-l-4 border-[#FFB703]">
              <div className="w-16 h-16 bg-[#FFB703]/10 rounded-full flex items-center justify-center mb-6">
                <Users className="text-[#FFB703]" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-black mb-4 font-cormorant">
                Meditații de grup
              </h3>
              <p className="text-gray-700 mb-6 font-lora">
                Grupuri mici (2-3 elevi) pentru o experiență de învățare colaborativă și dinamică. Ideale pentru socializare și învățare între colegi.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Învățare colaborativă</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Motivație prin interacțiune</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Grup omogen ca nivel</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 font-lora">Tarif accesibil</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 p-10 rounded-3xl mb-16 border border-[#FFB703]">
            <div className="text-center mb-8">
              <GraduationCap className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Pregătire pentru examene
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Programe specializate pentru cei care se pregătesc pentru momente decisive ale parcursului educațional
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Pregătire Bacalaureat
                </h3>
                <p className="text-gray-700 mb-4 font-lora">
                  Program intensiv pentru examenul de Bacalaureat, acoperind toate materiile obligatorii și opționale.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Simulări complete de examen
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Tehnici de rezolvare eficientă
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Materiale actualizate anual
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Gestionarea stresului pre-examen
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Pregătire admitere facultate
                </h3>
                <p className="text-gray-700 mb-4 font-lora">
                  Program personalizat în funcție de facultatea dorită și cerințele specifice ale examenului de admitere.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Subiecte din ani anteriori
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Strategii de răspuns
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Consiliere pentru alegerea facultății
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Pregătire intensivă concentrată
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Pregătire evaluare națională
                </h3>
                <p className="text-gray-700 mb-4 font-lora">
                  Program dedicat elevilor de clasa a VIII-a pentru pregătirea examenului de evaluare națională.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Simulări complete de evaluare
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Materiale din anii anteriori
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Strategii de examen eficiente
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#00A8CC] rounded-full"></div>
                    Suport emoțional și motivație
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  Pregătire și ajutor la teme
                </h3>
                <p className="text-gray-700 mb-4 font-lora">
                  Program special pentru elevii claselor 0-4, focusat pe dezvoltarea abilităților fundamentale și ajutor la teme.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Consolidare cunoștințe de bază
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Asistență la teme zilnice
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Dezvoltare abilități de studiu
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-700 font-lora">
                    <div className="w-1.5 h-1.5 bg-[#FFB703] rounded-full"></div>
                    Îndrumarea părinților
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mb-16">
            <div className="text-center mb-8">
              <BookOpen className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Planuri de învățare personalizate
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Fiecare elev primește un program de studiu creat special pentru el
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-[#00A8CC]">
                <div className="w-12 h-12 bg-[#00A8CC]/10 rounded-full flex items-center justify-center mb-4">
                  <Target className="text-[#00A8CC]" size={24} />
                </div>
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  1. Evaluare inițială
                </h3>
                <p className="text-gray-700 font-lora">
                  Identificăm nivelul actual de cunoștințe și zonele care necesită atenție specială.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-[#FFB703]">
                <div className="w-12 h-12 bg-[#FFB703]/10 rounded-full flex items-center justify-center mb-4">
                  <BookOpen className="text-[#FFB703]" size={24} />
                </div>
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  2. Plan personalizat
                </h3>
                <p className="text-gray-700 font-lora">
                  Creăm un program de studiu adaptat obiectivelor elevului, cu materiale și exerciții specifice.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-black">
                <div className="w-12 h-12 bg-black/10 rounded-full flex items-center justify-center mb-4">
                  <Clock className="text-black" size={24} />
                </div>
                <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                  3. Monitorizare continuă
                </h3>
                <p className="text-gray-700 font-lora">
                  Ajustăm programul în funcție de progresul elevului și feedback-ul primit.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-10 rounded-3xl shadow-xl text-center border border-yellow-200">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Materii disponibile
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora mb-6">
                Centrul INTEGRA oferă meditații în următoarele discipline
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {subjectPricing.map((subject, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedSubject(subject)}
                  className="bg-gradient-to-br from-[#00A8CC]/10 to-[#FFB703]/10 p-4 rounded-xl hover:from-[#00A8CC]/20 hover:to-[#FFB703]/20 transition-all hover:shadow-lg transform hover:scale-105 cursor-pointer"
                >
                  <p className="text-black font-lora font-semibold">{subject.name}</p>
                </button>
              ))}
            </div>

            <div className="mt-8">
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Limbi străine - Materiale interactive
              </h3>
              <p className="text-gray-700 font-lora mb-4">
                Grupe de 2, 3 sau mai mulți elevi cu acces la resurse multimedia moderne
              </p>
              <div className="inline-block bg-[#00A8CC] text-white px-6 py-2 rounded-full font-lora">
                Engleză • Germană
              </div>
            </div>
          </div>

          {selectedSubject && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedSubject(null)}>
              <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                <div className="sticky top-0 bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white p-6 rounded-t-3xl flex justify-between items-center">
                  <h3 className="text-2xl font-bold font-cormorant">{selectedSubject.name}</h3>
                  <button
                    onClick={() => setSelectedSubject(null)}
                    className="bg-white/20 hover:bg-white/30 rounded-full p-2 transition-all"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="p-6">
                  <div className="mb-6">
                    <h4 className="text-lg font-bold text-gray-900 mb-4 font-cormorant">Planuri tarifare disponibile:</h4>
                  </div>

                  <div className="space-y-6">
                    {selectedSubject.levels.map((level, idx) => (
                      <div key={idx} className="bg-gradient-to-br from-gray-50 to-yellow-50 p-6 rounded-2xl border-2 border-[#FFB703]/20">
                        <h5 className="text-xl font-bold text-black mb-4 font-cormorant">{level.title}</h5>

                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div className="bg-white p-4 rounded-xl shadow-sm">
                            <p className="text-sm text-gray-600 mb-1 font-lora">Durată ședință:</p>
                            <p className="text-lg font-bold text-black font-lora">{level.duration}</p>
                          </div>

                          <div className="bg-white p-4 rounded-xl shadow-sm">
                            <p className="text-sm text-gray-600 mb-1 font-lora">Preț pe ședință:</p>
                            <p className="text-lg font-bold text-[#00A8CC] font-lora">{level.pricePerSession}</p>
                          </div>
                        </div>

                        <div className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] p-4 rounded-xl text-white">
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-sm font-lora">Abonament lunar (4 ședințe/lună):</p>
                            <span className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                              -{level.discount} discount
                            </span>
                          </div>
                          <p className="text-2xl font-bold font-lora">{level.monthlySubscription}</p>
                          <p className="text-xs text-white/80 mt-1 font-lora">
                            Economisești {(parseFloat(level.pricePerSession) * 4 - parseFloat(level.monthlySubscription)).toFixed(0)} lei/lună
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 bg-blue-50 p-4 rounded-xl border border-blue-200">
                    <p className="text-sm text-gray-700 font-lora">
                      <strong>Notă:</strong> Toate abonamentele includ materiale de studiu.
                      Pentru mai multe detalii sau pentru a programa prima ședință, contactează-ne!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold text-black mb-6 font-cormorant">
              Pentru cine sunt meditațiile?
            </h2>

            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="p-6 bg-yellow-50 rounded-2xl border border-[#FFB703]">
                <h3 className="text-xl font-bold text-black mb-2 font-cormorant">
                  Copii
                </h3>
                <p className="text-gray-700 mb-2 font-lora">De la clasa I</p>
                <p className="text-sm text-gray-600 font-lora">
                  Dezvoltăm fundamentele solide pentru succes școlar
                </p>
              </div>

              <div className="p-6 bg-gray-50 rounded-2xl">
                <h3 className="text-xl font-bold text-black mb-2 font-cormorant">
                  Adolescenți
                </h3>
                <p className="text-gray-700 mb-2 font-lora">Gimnaziu și liceu</p>
                <p className="text-sm text-gray-600 font-lora">
                  Pregătire pentru examene și consolidare cunoștințe
                </p>
              </div>

              <div className="p-6 bg-blue-50 rounded-2xl border border-[#00A8CC]">
                <h3 className="text-xl font-bold text-black mb-2 font-cormorant">
                  Adulți
                </h3>
                <p className="text-gray-700 mb-2 font-lora">Bacalaureat & Admitere</p>
                <p className="text-sm text-gray-600 font-lora">
                  Reluare materie și pregătire intensivă
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
