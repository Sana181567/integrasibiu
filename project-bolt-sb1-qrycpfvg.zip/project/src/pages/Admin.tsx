import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Mail, User, Calendar, Trash2, Phone as PhoneIcon, Tag, LogOut, Lock } from 'lucide-react';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  created_at: string;
}

export default function Admin() {
  const [submissions, setSubmissions] = useState<ContactSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setIsAuthenticated(true);
        fetchSubmissions();
      } else {
        setLoading(false);
      }
    } catch (err) {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoggingIn(true);
    setLoginError(null);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginForm.email,
        password: loginForm.password,
      });

      if (error) throw error;

      if (data.session) {
        setIsAuthenticated(true);
        fetchSubmissions();
      }
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Eroare la autentificare');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsAuthenticated(false);
    setSubmissions([]);
  };

  const fetchSubmissions = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('contact_submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSubmissions(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'A apărut o eroare');
    } finally {
      setLoading(false);
    }
  };

  const deleteSubmission = async (id: string) => {
    if (!confirm('Sigur vrei să ștergi acest mesaj?')) return;

    try {
      const { error } = await supabase
        .from('contact_submissions')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setSubmissions(submissions.filter(s => s.id !== id));
    } catch (err) {
      alert('Eroare la ștergere: ' + (err instanceof Error ? err.message : 'Eroare necunoscută'));
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('ro-RO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-xl text-slate-600">Se încarcă...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-6 text-center">
              <Lock className="mx-auto h-12 w-12 text-white mb-3" />
              <h1 className="text-2xl font-bold text-white">Panou Administrator</h1>
              <p className="text-blue-100 mt-2">Autentificare necesară</p>
            </div>

            <form onSubmit={handleLogin} className="p-8 space-y-6">
              {loginError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
                  {loginError}
                </div>
              )}

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="admin@integra.ro"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-2">
                  Parolă
                </label>
                <input
                  type="password"
                  id="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="••••••••"
                />
              </div>

              <button
                type="submit"
                disabled={loggingIn}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loggingIn ? 'Se autentifică...' : 'Autentificare'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-xl text-red-600">Eroare: {error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-6 flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-white">Panou Administrator</h1>
              <p className="text-blue-100 mt-2">Mesaje primite din formularul de contact</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
              title="Deconectare"
            >
              <LogOut size={20} />
              <span className="hidden sm:inline">Deconectare</span>
            </button>
          </div>

          <div className="p-8">
            {submissions.length === 0 ? (
              <div className="text-center py-12">
                <Mail className="mx-auto h-16 w-16 text-slate-300 mb-4" />
                <p className="text-xl text-slate-600">Nu sunt mesaje încă</p>
                <p className="text-slate-500 mt-2">Mesajele din formularul de contact vor apărea aici</p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-sm text-slate-600 mb-4">
                  Total mesaje: <span className="font-semibold text-blue-600">{submissions.length}</span>
                </div>

                {submissions.map((submission) => (
                  <div
                    key={submission.id}
                    className="border border-slate-200 rounded-xl p-6 hover:shadow-lg transition-shadow duration-200"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <User className="h-5 w-5 text-blue-600" />
                          <h3 className="text-lg font-semibold text-slate-800">{submission.name}</h3>
                        </div>
                        <div className="flex items-center gap-2 text-slate-600 mb-2">
                          <Mail className="h-4 w-4" />
                          <a
                            href={`mailto:${submission.email}`}
                            className="hover:text-blue-600 transition-colors"
                          >
                            {submission.email}
                          </a>
                        </div>
                        <div className="flex items-center gap-2 text-slate-600 mb-2">
                          <PhoneIcon className="h-4 w-4" />
                          <a
                            href={`tel:${submission.phone}`}
                            className="hover:text-blue-600 transition-colors"
                          >
                            {submission.phone}
                          </a>
                        </div>
                        <div className="flex items-center gap-2 text-slate-600 mb-2">
                          <Tag className="h-4 w-4" />
                          <span className="text-sm font-medium">{submission.subject}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <Calendar className="h-4 w-4" />
                          <span>{formatDate(submission.created_at)}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteSubmission(submission.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 p-2 rounded-lg transition-colors"
                        title="Șterge mesajul"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>

                    <div className="bg-slate-50 rounded-lg p-4 mt-4">
                      <p className="text-sm font-semibold text-slate-700 mb-2">Mesaj:</p>
                      <p className="text-slate-700 whitespace-pre-wrap">{submission.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
