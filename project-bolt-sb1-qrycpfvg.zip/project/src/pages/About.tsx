import { Target, Heart, Award, Users } from 'lucide-react';

export default function About() {
  return (
    <div>
      <section className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-16 px-4 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-5">
          <img
            src="/integra_logo.png"
            alt=""
            className="w-96 h-auto"
          />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1 className="text-5xl font-bold mb-6 font-cormorant">Despre INTEGRA</h1>
          <p className="text-xl text-white/90 font-lora">
            Mai mult decât meditații - o comunitate dedicată succesului fiecărui elev
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-4xl font-bold text-black mb-6 font-cormorant">
                Povestea noastră
              </h2>
              <p className="text-lg text-gray-700 mb-4 font-lora">
                INTEGRA a luat naștere din dorința de a oferi o educație autentică, personalizată și plină de sens. Am înțeles că fiecare copil are un ritm propriu de învățare și nevoi unice, iar sistemul tradițional nu întotdeauna reușește să le adreseze.
              </p>
              <p className="text-lg text-gray-700 mb-4 font-lora">
                Astfel, am creat un spațiu în care elevii se simt în siguranță să exploreze, să greșească și să învețe. Un loc unde fiecare întrebare este binevenită și fiecare progres este celebrat.
              </p>
              <p className="text-lg text-gray-700 font-lora">
                La INTEGRA, educația nu înseamnă doar note bune - înseamnă dezvoltare personală, încredere în sine și pasiune pentru cunoaștere.
              </p>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl border border-yellow-100">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#00A8CC]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Target className="text-[#00A8CC]" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-black mb-2 font-cormorant">Misiunea noastră</h3>
                    <p className="text-gray-700 font-lora">
                      Să oferim educație de calitate, accesibilă și personalizată, care să inspire și să dezvolte potențialul fiecărui elev.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FFB703]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Heart className="text-[#FFB703]" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-black mb-2 font-cormorant">Valorile noastre</h3>
                    <p className="text-gray-700 font-lora">
                      Empatie, dedicare, profesionalism și respect pentru unicitatea fiecărui elev.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-black/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Award className="text-black" size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-black mb-2 font-cormorant">Viziunea noastră</h3>
                    <p className="text-gray-700 font-lora">
                      Să devenim un centru de referință în educație personalizată, unde fiecare elev își poate atinge potențialul maxim.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 p-10 rounded-3xl mb-16 border border-[#FFB703]">
            <div className="text-center mb-8">
              <Users className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Echipa noastră
              </h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
                Profesorii noștri sunt mai mult decât cadre didactice - sunt mentori dedicați care cred în potențialul fiecărui elev. Cu experiență vastă în predare și o pasiune autentică pentru educație, echipa INTEGRA creează un mediu de învățare stimulativ și susținător.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-2xl text-center shadow-lg">
                <div className="w-20 h-20 bg-[#00A8CC]/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl font-bold text-[#00A8CC]">5+</span>
                </div>
                <h3 className="font-bold text-black mb-2 font-cormorant">Ani de experiență</h3>
                <p className="text-sm text-gray-700 font-lora">în domeniul educației și meditațiilor</p>
              </div>

              <div className="bg-white p-6 rounded-2xl text-center shadow-lg">
                <div className="w-20 h-20 bg-[#FFB703]/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl font-bold text-[#FFB703]">200+</span>
                </div>
                <h3 className="font-bold text-black mb-2 font-cormorant">Elevi ajutați</h3>
                <p className="text-sm text-gray-700 font-lora">să își atingă obiectivele academice</p>
              </div>

              <div className="bg-white p-6 rounded-2xl text-center shadow-lg">
                <div className="w-20 h-20 bg-black/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl font-bold text-black">95%</span>
                </div>
                <h3 className="font-bold text-black mb-2 font-cormorant">Rată de succes</h3>
                <p className="text-sm text-gray-700 font-lora">la examene și admitere</p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-bold text-black mb-6 font-cormorant">
              Ce ne face diferiți?
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-[#00A8CC]">
                <h3 className="font-bold text-black mb-2 font-cormorant">Abordare personalizată</h3>
                <p className="text-sm text-gray-700 font-lora">
                  Fiecare plan de studiu este adaptat nevoilor individuale ale elevului
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-[#FFB703]">
                <h3 className="font-bold text-black mb-2 font-cormorant">Atmosferă caldă</h3>
                <p className="text-sm text-gray-700 font-lora">
                  Un mediu prietenos unde elevii se simt confortabil și motivați
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-black">
                <h3 className="font-bold text-black mb-2 font-cormorant">Comunicare deschisă</h3>
                <p className="text-sm text-gray-700 font-lora">
                  Dialog constant cu părinții despre progresul și nevoile elevilor
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-[#00A8CC]">
                <h3 className="font-bold text-black mb-2 font-cormorant">Rezultate dovedite</h3>
                <p className="text-sm text-gray-700 font-lora">
                  Succes constant în pregătirea pentru examene și îmbunătățirea notelor
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
