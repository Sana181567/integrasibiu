import { BookOpen, Users, Trophy, Heart, ArrowRight, CheckCircle2 } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div>
      <section className="relative bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-20 px-4 overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 font-cormorant">
              Educație cu sens
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90">
              La INTEGRA, fiecare elev contează. Oferim meditații personalizate care ajută copiii și tinerii să-și atingă potențialul maxim, cu încredere și rezultate concrete.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('contact')}
                className="bg-[#FFB703] text-black px-8 py-4 rounded-full font-semibold text-lg hover:bg-yellow-400 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 font-lora"
              >
                Programează o ședință
              </button>
              <button
                onClick={() => onNavigate('tutoring')}
                className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-[#00A8CC] transition-all font-lora"
              >
                Află mai multe
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4 font-cormorant">
              Cum ajută meditațiile?
            </h2>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto font-lora">
              Meditațiile oferă un mediu sigur și structurat în care elevii pot învăța în ritmul lor, pot pune întrebări și pot construi o bază solidă de cunoștințe.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-[#00A8CC]/10 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="text-[#00A8CC]" size={28} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Învățare personalizată
              </h3>
              <p className="text-gray-700 font-lora">
                Fiecare elev primește atenție individuală și un plan de studiu adaptat nevoilor sale.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-[#FFB703]/10 rounded-full flex items-center justify-center mb-4">
                <Trophy className="text-[#FFB703]" size={28} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Rezultate măsurabile
              </h3>
              <p className="text-gray-700 font-lora">
                Note mai bune, pregătire solidă pentru examene și o înțelegere profundă a materiei.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-black/10 rounded-full flex items-center justify-center mb-4">
                <Users className="text-black" size={28} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Mediu prietenos
              </h3>
              <p className="text-gray-700 font-lora">
                Atmosferă caldă și primitoare, unde elevii se simt confortabil să își exprime dificultățile.
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-[#00A8CC]/10 rounded-full flex items-center justify-center mb-4">
                <Heart className="text-[#00A8CC]" size={28} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Încredere crescută
              </h3>
              <p className="text-gray-700 font-lora">
                Elevii câștigă încredere în abilitățile lor și își dezvoltă pasiunea pentru învățare.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-black mb-6 font-cormorant">
                Beneficii pentru elevi și părinți
              </h2>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="text-[#00A8CC] flex-shrink-0 mt-1" size={24} />
                  <p className="text-[#2C3E50]">
                    <strong>Pregătire individuală:</strong> Atenție dedicată fiecărui elev, indiferent de nivelul de cunoștințe
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="text-[#7EB09B] flex-shrink-0 mt-1" size={24} />
                  <p className="text-[#2C3E50]">
                    <strong>Flexibilitate:</strong> Program adaptat nevoilor familiei și elevului
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="text-[#7EB09B] flex-shrink-0 mt-1" size={24} />
                  <p className="text-[#2C3E50]">
                    <strong>Cadre didactice experimentate:</strong> Profesori dedicați cu experiență în predare
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="text-[#7EB09B] flex-shrink-0 mt-1" size={24} />
                  <p className="text-[#2C3E50]">
                    <strong>Monitorizare constantă:</strong> Comunicare deschisă cu părinții despre progresul elevilor
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="text-[#7EB09B] flex-shrink-0 mt-1" size={24} />
                  <p className="text-[#2C3E50]">
                    <strong>Locație centrală:</strong> Ușor accesibil în zona Calea Dumbravii din Sibiu
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] p-8 rounded-3xl text-white shadow-xl">
              <h3 className="text-2xl font-bold mb-4 font-cormorant">
                De ce să alegi INTEGRA?
              </h3>
              <p className="mb-6 text-white/90 font-lora">
                Suntem mai mult decât un centru de meditații. Suntem o comunitate dedicată succesului fiecărui elev. Aici, educația are cu adevărat sens.
              </p>
              <ul className="space-y-3 mb-6 font-lora">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                  <span>Copii de la clasa I</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                  <span>Elevi de gimnaziu și liceu</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#FFB703] rounded-full"></div>
                  <span>Adulți pregătire Bacalaureat/Admitere</span>
                </li>
              </ul>
              <button
                onClick={() => onNavigate('about')}
                className="bg-[#FFB703] text-black px-6 py-3 rounded-full font-semibold hover:bg-yellow-400 transition-all flex items-center gap-2 font-lora"
              >
                Descoperă povestea noastră
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-yellow-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-black mb-6 font-cormorant">
            Gata să începi?
          </h2>
          <p className="text-lg text-gray-700 mb-8 font-lora">
            Alătură-te comunității INTEGRA și descoperă cum educația cu sens poate transforma viitorul copilului tău.
          </p>
          <button
            onClick={() => onNavigate('contact')}
            className="bg-[#00A8CC] text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-[#0086AC] transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 font-lora"
          >
            Contactează-ne acum
          </button>
        </div>
      </section>
    </div>
  );
}
