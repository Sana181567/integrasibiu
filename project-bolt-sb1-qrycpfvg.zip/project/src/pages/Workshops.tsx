import { Palette, Calendar, Users, Image, FlaskConical, CheckCircle2 } from 'lucide-react';

interface WorkshopsProps {
  onNavigate: (page: string) => void;
}

export default function Workshops({ onNavigate }: WorkshopsProps) {
  const pastWorkshops = [
    {
      title: 'Atelier creație ornamente de Crăciun',
      description: 'Copiii au creat ornamente festive pentru sezonul sărbătorilor, dezvoltând creativitatea și abilitățile manuale.',
      language: 'în limba engleză',
      icon: Palette,
      color: 'bg-red-100 text-red-600',
      borderColor: 'border-red-400',
    },
  ];

  const upcomingWorkshops = [
    {
      title: 'Atelier de disecție – Ochi, Rinichi, Inimă',
      description: 'Te invităm la un atelier practic de disecție biologică, unde vei avea ocazia să explorezi structura reală a unor organe esențiale: ochi, rinichi și inimă.',
      activities: [
        'Observi direct organele, le atingi și înțelegi funcțiile fiecărei părți prin explicații clare',
        'Lucrezi ghidat, pas cu pas, într-un mediu sigur și restrâns',
        'Pui întrebări și faci conexiuni utile pentru școală și examene'
      ],
      date: '14-15 februarie, 10:00-12:00',
      deadline: 'Înscrieri până în 8 februarie',
      phone: '0775 582 002',
      target: 'Potrivit pentru elevi de gimnaziu și liceu, pasionați de biologie',
      image: '/atelier_disectie.png',
      icon: FlaskConical,
      color: 'bg-rose-100 text-rose-600',
      borderColor: 'border-rose-400',
    },
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Palette className="mx-auto mb-6" size={64} />
          <h1 className="text-5xl font-bold mb-6 font-cormorant">Ateliere de creație</h1>
          <p className="text-xl text-white/90 font-lora">
            Experiențe educaționale interactive care stimulează creativitatea și curiozitatea elevilor
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4 font-cormorant">
              Ce sunt atelierele INTEGRA?
            </h2>
            <p className="text-lg text-gray-700 max-w-3xl mx-auto font-lora">
              Pe lângă meditațiile regulate, organizăm periodic ateliere tematice care oferă elevilor
              oportunitatea de a învăța prin experiență practică, în contexte diferite de cele tradiționale.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-yellow-50 p-8 rounded-3xl text-center border-2 border-[#FFB703]">
              <div className="w-16 h-16 bg-[#FFB703]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-[#FFB703]" size={32} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Învățare colaborativă
              </h3>
              <p className="text-gray-700 font-lora">
                Elevii lucrează împreună în proiecte creative, dezvoltând abilități sociale și de teamwork
              </p>
            </div>

            <div className="bg-blue-50 p-8 rounded-3xl text-center border-2 border-[#00A8CC]">
              <div className="w-16 h-16 bg-[#00A8CC]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="text-[#00A8CC]" size={32} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Experiență practică
              </h3>
              <p className="text-gray-700 font-lora">
                Activități hands-on care transformă teoria în practică și fac învățarea mai captivantă
              </p>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl text-center border-2 border-black">
              <div className="w-16 h-16 bg-black/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="text-black" size={32} />
              </div>
              <h3 className="text-xl font-bold text-black mb-3 font-cormorant">
                Tematici variate
              </h3>
              <p className="text-gray-700 font-lora">
                De la arte creative la științe experimentale, oferim o gamă diversă de experiențe educaționale
              </p>
            </div>
          </div>

          <div className="mb-16">
            <div className="text-center mb-10">
              <Calendar className="text-[#00A8CC] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Ateliere viitoare
              </h2>
              <p className="text-lg text-gray-700 font-lora">
                Urmăriți următoarele noastre evenimente educaționale
              </p>
            </div>

            <div className="space-y-6">
              {upcomingWorkshops.map((workshop, index) => {
                const Icon = workshop.icon;
                return (
                  <div
                    key={index}
                    className={`bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all border-2 ${workshop.borderColor} overflow-hidden`}
                  >
                    {workshop.image && (
                      <div className="w-full">
                        <img
                          src={workshop.image}
                          alt={workshop.title}
                          className="w-full h-auto object-cover"
                        />
                      </div>
                    )}
                    <div className="p-8">
                      <div className="flex flex-col md:flex-row gap-6 items-start mb-6">
                        <div className={`w-20 h-20 ${workshop.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                          <Icon size={40} />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-3xl font-bold text-black mb-4 font-cormorant">
                            {workshop.title}
                          </h3>
                          <p className="text-gray-700 mb-4 font-lora text-lg">
                            {workshop.description}
                          </p>
                        </div>
                      </div>

                      {workshop.activities && (
                        <div className="mb-6 bg-gray-50 p-6 rounded-2xl">
                          <h4 className="text-xl font-bold text-black mb-4 font-cormorant">
                            Ce vei face concret?
                          </h4>
                          <ul className="space-y-3">
                            {workshop.activities.map((activity, actIndex) => (
                              <li key={actIndex} className="flex items-start gap-3">
                                <CheckCircle2 className="text-[#00A8CC] flex-shrink-0 mt-1" size={20} />
                                <span className="text-gray-700 font-lora">{activity}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        {workshop.date && (
                          <div className="bg-blue-50 p-4 rounded-xl border-2 border-[#00A8CC]/20">
                            <div className="flex items-center gap-2 mb-2">
                              <Calendar className="text-[#00A8CC]" size={20} />
                              <span className="font-bold text-black font-cormorant">Data</span>
                            </div>
                            <p className="text-gray-700 font-lora">{workshop.date}</p>
                          </div>
                        )}

                        {workshop.deadline && (
                          <div className="bg-red-50 p-4 rounded-xl border-2 border-rose-400/20">
                            <div className="flex items-center gap-2 mb-2">
                              <Calendar className="text-rose-600" size={20} />
                              <span className="font-bold text-black font-cormorant">Înscrieri</span>
                            </div>
                            <p className="text-gray-700 font-lora">{workshop.deadline}</p>
                          </div>
                        )}
                      </div>

                      {workshop.target && (
                        <div className="bg-yellow-50 p-4 rounded-xl border-2 border-[#FFB703]/20 mb-6">
                          <div className="flex items-center gap-2 mb-2">
                            <Users className="text-[#FFB703]" size={20} />
                            <span className="font-bold text-black font-cormorant">Publicul țintă</span>
                          </div>
                          <p className="text-gray-700 font-lora">{workshop.target}</p>
                        </div>
                      )}

                      {workshop.phone && (
                        <div className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] p-6 rounded-2xl text-white text-center">
                          <p className="text-lg mb-2 font-lora">Înscrieri în mesaj privat la numărul:</p>
                          <a
                            href={`tel:${workshop.phone}`}
                            className="text-2xl font-bold hover:text-[#FFB703] transition-colors font-cormorant"
                          >
                            {workshop.phone}
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mb-16">
            <div className="text-center mb-10">
              <Image className="text-[#FFB703] mx-auto mb-4" size={48} />
              <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
                Ateliere anterioare
              </h2>
              <p className="text-lg text-gray-700 font-lora">
                Iată câteva dintre evenimentele noastre de succes din trecut
              </p>
            </div>

            <div className="space-y-6">
              {pastWorkshops.map((workshop, index) => {
                const Icon = workshop.icon;
                return (
                  <div
                    key={index}
                    className={`bg-white p-8 rounded-3xl shadow-xl border-2 ${workshop.borderColor}`}
                  >
                    <div className="flex flex-col md:flex-row gap-6 items-start">
                      <div className={`w-20 h-20 ${workshop.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                        <Icon size={40} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-black mb-3 font-cormorant">
                          {workshop.title}
                        </h3>
                        <div className="inline-block bg-[#FFB703] text-white px-4 py-1 rounded-full text-sm font-semibold mb-3">
                          {workshop.language}
                        </div>
                        <p className="text-gray-700 font-lora text-lg">
                          {workshop.description}
                        </p>
                      </div>
                    </div>
                    <div className="mt-6">
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {[
                          'whatsapp_image_2026-01-21_at_20.14.11.jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.11_(1).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.11_(2).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.12.jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.12_(1).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.13.jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.13_(2).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.14.jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.14_(1).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.14_(2).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.27_(1).jpeg',
                          'whatsapp_image_2026-01-21_at_20.14.28_(1).jpeg',
                        ].map((image, idx) => (
                          <div
                            key={idx}
                            className="aspect-square rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer border-2 border-red-200"
                          >
                            <img
                              src={`/${image}`}
                              alt={`Atelier Crăciun ${idx + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#00A8CC]/10 to-[#FFB703]/10 p-10 rounded-3xl shadow-xl text-center border-2 border-[#00A8CC]/20">
            <Palette className="text-[#00A8CC] mx-auto mb-4" size={48} />
            <h2 className="text-3xl font-bold text-black mb-4 font-cormorant">
              Interesat de următorul atelier?
            </h2>
            <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto font-lora">
              Contactează-ne pentru a afla mai multe despre atelierele viitoare și pentru a-ți rezerva un loc.
              Locurile sunt limitate pentru a asigura o experiență de calitate pentru fiecare participant.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="bg-[#00A8CC] text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-[#0086AC] transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Solicită informații
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
