import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      console.log('Sending form data:', formData);
      console.log('API URL:', `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-contact-email`);

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-contact-email`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            subject: formData.subject,
            message: formData.message,
          }),
        }
      );

      console.log('Response status:', response.status);
      const data = await response.json();
      console.log('Response data:', data);

      if (response.ok) {
        setSubmitted(true);
        setTimeout(() => {
          setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
          setSubmitted(false);
        }, 5000);
      } else {
        setError(data.error || 'A apărut o eroare la trimiterea mesajului. Încearcă din nou.');
      }
    } catch (error) {
      console.error('Error sending email:', error);
      setError('A apărut o eroare la trimiterea mesajului. Verifică conexiunea la internet.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <section className="bg-gradient-to-br from-[#00A8CC] to-[#0086AC] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6 font-cormorant">Contact</h1>
          <p className="text-xl text-white/90 font-lora">
            Suntem aici să răspundem la întrebările tale și să te ajutăm
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-3xl font-bold text-black mb-8 font-cormorant">
                Informații de contact
              </h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#00A8CC]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="text-[#00A8CC]" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-black mb-1 font-lora">Adresă</h3>
                    <p className="text-gray-700 font-lora">
                      Calea Dumbravii, nr. 97<br />
                      Sibiu, România
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FFB703]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="text-[#FFB703]" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-black mb-1 font-lora">Telefon</h3>
                    <p className="text-gray-700 font-lora">
                      0775582002
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-black/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="text-black" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-black mb-1 font-lora">Email</h3>
                    <p className="text-gray-700 font-lora">
                      integrasibiu@gmail.com
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#00A8CC]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="text-[#00A8CC]" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-black mb-1 font-lora">Program</h3>
                    <p className="text-gray-700 font-lora">
                      Luni - Vineri: 08:00 - 21:00<br />
                      Sâmbătă: 09:00 - 20:00<br />
                      Duminică: Program special (la cerere)
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-yellow-50 rounded-2xl border border-[#FFB703]">
                <h3 className="font-bold text-black mb-3 font-lora">
                  Cum ajungi la noi?
                </h3>
                <p className="text-gray-700 text-sm font-lora mb-2">
                  Centrul INTEGRA este situat pe Calea Dumbravii, o arteră principală din Sibiu, ușor accesibilă atât cu mașina, cât și cu transportul în comun.
                </p>
                <p className="text-gray-700 text-sm font-lora">
                  Parcare disponibilă în zonă.
                </p>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl shadow-xl border border-yellow-100">
              <h2 className="text-3xl font-bold text-black mb-2 font-cormorant">
                Trimite-ne un mesaj
              </h2>
              <p className="text-gray-700 mb-6 font-lora">
                Completează formularul și îți vom răspunde în cel mai scurt timp
              </p>

              {submitted ? (
                <div className="bg-[#00A8CC]/10 border-2 border-[#00A8CC] p-6 rounded-2xl text-center">
                  <div className="w-16 h-16 bg-[#00A8CC] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="text-white" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-black mb-2 font-cormorant">
                    Mesaj trimis cu succes!
                  </h3>
                  <p className="text-gray-700 font-lora">
                    Îți mulțumim pentru mesaj. Îți vom răspunde în cel mai scurt timp posibil.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <div className="bg-red-50 border-2 border-red-500 p-4 rounded-xl text-red-700 font-lora">
                      {error}
                    </div>
                  )}

                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-black mb-2 font-lora">
                      Nume complet *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#FFB703] focus:border-[#00A8CC] focus:outline-none transition-colors bg-white font-lora"
                      placeholder="Ion Popescu"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-black mb-2 font-lora">
                      Email *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#FFB703] focus:border-[#00A8CC] focus:outline-none transition-colors bg-white font-lora"
                      placeholder="ion.popescu@email.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-black mb-2 font-lora">
                      Telefon *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#FFB703] focus:border-[#00A8CC] focus:outline-none transition-colors bg-white font-lora"
                      placeholder="+40 XXX XXX XXX"
                    />
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-semibold text-black mb-2 font-lora">
                      Subiect *
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#FFB703] focus:border-[#00A8CC] focus:outline-none transition-colors bg-white font-lora"
                    >
                      <option value="">Selectează un subiect</option>
                      <option value="informații">Informații generale</option>
                      <option value="programare">Programare evaluare</option>
                      <option value="meditații">Întrebări despre meditații</option>
                      <option value="preturi">Prețuri și pachete</option>
                      <option value="altele">Altele</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-black mb-2 font-lora">
                      Mesaj *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#FFB703] focus:border-[#00A8CC] focus:outline-none transition-colors resize-none bg-white font-lora"
                      placeholder="Scrie-ne mesajul tău aici..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#00A8CC] text-white py-4 rounded-xl font-semibold text-lg hover:bg-[#0086AC] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 font-lora"
                  >
                    <Send size={20} />
                    {loading ? 'Se trimite...' : 'Trimite mesajul'}
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="h-[500px] relative">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2754.8!2d24.137!3d45.797!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x474c67c7c7c7c7c7%3A0x7c7c7c7c7c7c7c7!2sCalea%20Dumbravii%2097%2C%20Sibiu!5e0!3m2!1sen!2sro!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Locația centrului INTEGRA pe hartă"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
