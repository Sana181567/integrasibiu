import { MapPin, Phone, Mail, Heart, Facebook } from 'lucide-react';

interface FooterProps {
  onNavigate?: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-black text-white py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <img
              src="/integra_logo.png"
              alt="INTEGRA"
              className="h-16 w-auto mb-4 opacity-90 hover:opacity-100 transition-opacity"
            />
            <p className="text-white/70 mb-4 font-lora">
              Educație cu sens pentru fiecare elev
            </p>
            <p className="text-sm text-white/60 font-lora">
              Centru de meditații personalizate în Sibiu, dedicat succesului academic al elevilor de toate vârstele.
            </p>
          </div>

          <div>
            <h4 className="font-bold font-lora mb-4">Contact</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                <MapPin size={18} className="text-[#FFB703] flex-shrink-0 mt-1" />
                <p className="text-sm text-white/70 font-lora">
                  Calea Dumbravii, nr. 97<br />
                  Sibiu, România
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Phone size={18} className="text-[#FFB703] flex-shrink-0" />
                <p className="text-sm text-white/70 font-lora">0775582002</p>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={18} className="text-[#FFB703] flex-shrink-0" />
                <p className="text-sm text-white/70 font-lora">integrasibiu@gmail.com</p>
              </div>
              <div className="flex items-center gap-2 mt-4">
                <a
                  href="https://www.facebook.com/profile.php?id=61582489357683"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-white/70 hover:text-[#00A8CC] transition-colors"
                >
                  <Facebook size={18} className="text-[#FFB703] flex-shrink-0" />
                  <span className="text-sm font-lora">Urmărește-ne pe Facebook</span>
                </a>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold font-lora mb-4">Program</h4>
            <div className="text-sm text-white/70 font-lora space-y-2">
              <p>Luni - Vineri: 08:00 - 21:00</p>
              <p>Sâmbătă: 09:00 - 20:00</p>
              <p>Duminică: Program special</p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 text-center">
          <p className="text-sm text-white/60 flex items-center justify-center gap-2">
            Creat cu <Heart size={16} className="text-[#FFB703]" fill="#FFB703" /> pentru comunitatea educațională din Sibiu
          </p>
          <p className="text-xs text-white/40 mt-2">
            © {new Date().getFullYear()} INTEGRA - Centru de Meditații. Toate drepturile rezervate.
          </p>
          {onNavigate && (
            <button
              onClick={() => onNavigate('admin')}
              className="text-xs text-white/20 hover:text-white/40 mt-2 transition-colors"
            >
              Admin
            </button>
          )}
        </div>
      </div>
    </footer>
  );
}
