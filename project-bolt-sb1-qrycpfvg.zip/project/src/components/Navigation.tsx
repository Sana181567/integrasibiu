import { Menu, X } from 'lucide-react';
import { useState } from 'react';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { id: 'home', label: 'Acasă' },
    { id: 'about', label: 'Despre noi' },
    { id: 'tutoring', label: 'Meditații' },
    { id: 'workshops', label: 'Ateliere' },
    { id: 'programs', label: 'Programe & Programări' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogoClick = () => {
    if (currentPage === 'home') {
      window.location.reload();
    } else {
      handleNavigate('home');
    }
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-28">
          <div className="flex-shrink-0 cursor-pointer py-2" onClick={handleLogoClick}>
            <img
              src="/integra_logo.png"
              alt="INTEGRA Centru Educational"
              className="h-24 w-auto hover:opacity-90 transition-opacity"
            />
          </div>

          <div className="hidden md:flex space-x-8">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === item.id
                    ? 'text-white bg-[#00A8CC]'
                    : 'text-black hover:text-[#00A8CC] hover:bg-yellow-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-[#00A8CC] hover:bg-yellow-50"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-yellow-200">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`block w-full text-left px-3 py-3 rounded-lg text-base font-medium transition-all ${
                  currentPage === item.id
                    ? 'text-white bg-[#00A8CC]'
                    : 'text-black hover:text-[#00A8CC] hover:bg-yellow-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
